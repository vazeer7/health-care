package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;

@SpringBootApplication
@ComponentScan(basePackages = {"com.example"})
@OpenAPIDefinition
public class SpringRestBranchDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestBranchDemoApplication.class, args);
	}

}
